package com.capgemini.truckbooking.Client;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.truckbooking.bean.BookingBean;
import com.capgemini.truckbooking.bean.TruckBean;
import com.capgemini.truckbooking.exception.TTBException;
import com.capgemini.truckbooking.service.CustomerValidation;
import com.capgemini.truckbooking.service.ITruckService;
import com.capgemini.truckbooking.service.TruckService;

public class BookingClient {
	static String bookingId="1000";
	private static Scanner sc=new Scanner(System.in);
	private static ITruckService truckService=new TruckService();
	
	
	//private static Logger myUILogger=Logger.getLogger(BookingClient.class);
	

	public static void main(String[] args) {
		while(true){
			System.out.println();
			System.out.println();
			System.out.println("Transport Truck Booking Online");
			System.out.println("_______________________________\n");
			
			System.out.println("1.Book Trucks");
			System.out.println("2.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
		// accept option

			try {
				int option = sc.nextInt();
				switch (option) {
				case 1:
					
					System.out.println("Enter CustomerId:");
					String custId=sc.next();
					//List<TruckBean> TruckList=getAllTruckDetails();
					//showTrucks(TruckList);
					System.out.println(" Please Enter the  TruckId: ");
					 int truckId=sc.nextInt();
					System.out.println("Enter number of trucks");
					int noOfTrucks=sc.nextInt();
					System.out.print("Enter Date: "); 
					 String dateOfTransport= sc.next(); 
					//sc.nextLine();//clear kbd buffer
					System.out.println("Enter 10 digit Phone Number:");
					long custMobile=sc.nextLong();
					
					BookingBean booking=new BookingBean();
					booking.setCustId(custId);
					booking.setTruckId(truckId);
					booking.setNoOfTrucks(noOfTrucks);
					booking.setDateOfTransport(dateOfTransport);
					String bookingId=addBookingDetails(custId,truckId,noOfTrucks,dateOfTransport,custMobile);
					System.out.println("Thank you. your booking Id is:"+bookingId);
					
					
					
					
					/*CustomerValidation validator=new CustomerValidation();
					if(validator.isValidCustomerId(custId)){
						if(validator.isValidPhoneNumber(custMobile)){
							System.out.println("red");
							
						}*/
		
					break;
				
				case 2:
					System.out.print("Exit Trust Application");
					System.exit(0);
				
					break;
					default:
					
						System.out.println("Enter a valid option[1-6]");
					
				}// end of switch
			
			}catch (InputMismatchException e) {
				//myUILogger.warn("Enter only valid data");
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
						
			}
			
			}
			}// end of while
				
	
	private static void showTrucks(List<TruckBean> truckList) {
		// TODO Auto-generated method stub
		
	}


	private static List<TruckBean> getAllTruckDetails() {
		// TODO Auto-generated method stub
		return null;
	}


	private static String addBookingDetails(String custId, int truckId,
			int noOfTrucks, String dateOfTransport, long custMobile) {
		try{
			
			String status=truckService.addTruck(custId,truckId,noOfTrucks,dateOfTransport,custMobile,bookingId);
			return status;
		}catch(TTBException e){
			System.out.println(e.getMessage());
		}
		return null;
	}



	

}
