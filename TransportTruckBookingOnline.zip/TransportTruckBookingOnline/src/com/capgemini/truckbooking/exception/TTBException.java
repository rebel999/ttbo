package com.capgemini.truckbooking.exception;

public class TTBException extends Exception {
	private static final long serialVersionUID = 1L;
	private String message;
	
	
	public TTBException() {
		
	}


	public TTBException(String message) {
		super();
		this.message = message;
	}




	public String getMessage() {
		return message;
	}


	@Override
	public String toString() {
		return "TTBException [message=" + message + "]";
	}
	
	
	

}
