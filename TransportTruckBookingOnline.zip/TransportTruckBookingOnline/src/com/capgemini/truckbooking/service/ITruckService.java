package com.capgemini.truckbooking.service;

import com.capgemini.truckbooking.exception.TTBException;

public interface ITruckService {
	
	public String addTruck(String custId,int noOfTrucks, int truckId, String bookingId, long custMobile, String dateOfTransport) throws TTBException;
}
