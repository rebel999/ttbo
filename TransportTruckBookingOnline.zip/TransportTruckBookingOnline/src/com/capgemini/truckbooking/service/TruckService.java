package com.capgemini.truckbooking.service;

import com.capgemini.truckbooking.dao.ITruckDao;
import com.capgemini.truckbooking.dao.TruckDao;
import com.capgemini.truckbooking.exception.TTBException;

public class TruckService implements ITruckService{
	
	private ITruckDao truckDao=new TruckDao();





	@Override
	public String addTruck(String custId, int noOfTrucks, int truckId,
			String bookingId, long custMobile, String dateOfTransport)
			throws TTBException {
		// TODO Auto-generated method stub
		return truckDao.addTruck(bookingId,custId,truckId,noOfTrucks,dateOfTransport,custMobile);
	}

	

	
	
	
}
