package com.capgemini.truckbooking.service;

import java.util.regex.Pattern;

public class CustomerValidation {
	
	
	public Boolean isValidCustomerId(String custId){
		String regex="[A-Z]\\d{6}$";
		
		return Pattern.matches(regex,custId);
	}
	
	public Boolean isValidPhoneNumber(Long phoneNumber){
		String mobile=phoneNumber.toString();
		String regex="[1-9][0-9]{9}$";
		return Pattern.matches(regex, mobile);
	}
	
}
