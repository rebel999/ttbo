package com.capgemini.truckbooking.dao;

import com.capgemini.truckbooking.exception.TTBException;

public interface ITruckDao {
	public String addTruck(String bookingId, String custId, int truckId, int noOfTrucks, String dateOfTransport, long custMobile) throws TTBException;

	
}
