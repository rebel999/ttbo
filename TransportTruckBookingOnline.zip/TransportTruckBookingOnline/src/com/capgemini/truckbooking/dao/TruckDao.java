package com.capgemini.truckbooking.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.truckbooking.exception.TTBException;
import com.capgemini.truckbooking.util.DBConnection;

public class TruckDao implements ITruckDao {

	@Override
	public String addTruck(String bookingId, String custId, int truckId,
			int noOfTrucks, String dateOfTransport,long custMobile) throws TTBException {
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement(IQueryMapper.ADD_TRUCK);
				){
				
				preparedStatement.setString(1, bookingId);
				preparedStatement.setString(2, custId);
				preparedStatement.setLong(3, custMobile);
				preparedStatement.setInt(4, truckId);
				preparedStatement.setInt(5, noOfTrucks);
				preparedStatement.setString(6, dateOfTransport);
				System.out.println("before result");
				ResultSet resultSet=preparedStatement.executeQuery();
				System.out.println("after result");
				if(resultSet.next()){
				  return "Success";
				}else{
					return "fail";
				}
			
		}catch(SQLException e){
			System.out.println(e.getMessage());
		}
		return null;
	}

	

}
