package com.capgemini.truckbooking.dao;

public interface IQueryMapper {
	
	public static final String ADD_TRUCK="INSERT INTO BookingDetails VALUES(?,?,?,?,?,?)";

}
